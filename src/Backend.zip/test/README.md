## Testing Report
Refer to `\tests\testing-report.pdf` in the **Frontend repository**.