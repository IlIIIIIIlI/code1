module.exports = {
    preset: '@shelf/jest-mongodb',
    testEnvironment: 'node',
    maxConcurrency: 1,
    //setupFilesAfterEnv: ['./jest.setup.js']
};