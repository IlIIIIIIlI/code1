class QuestionTree {
    constructor(root, size) {
        this._root = root;
    }

    root() {
        return this._root;
    }
}