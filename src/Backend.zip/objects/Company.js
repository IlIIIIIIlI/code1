class Company {
    constructor(placeholder) {
        this._placeholder = placeholder;
    }

    placeholder() {
        return this._placeholder;
    }
}