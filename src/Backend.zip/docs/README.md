## Project Documentation
Refer to the  `\docs` directory in the **Frontend repository**.